# to do App

If you want to run the app from the repo,

- Clone the repository and run `npm start` in the project root
- Follow the instructions to open it with the [Expo app](https://expo.io/)
